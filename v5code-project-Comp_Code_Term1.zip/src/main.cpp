/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\99804199                                         */
/*    Created:      Tue Sep 27 2022                                           */
/*    Description:  Competition Code                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/


// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 10          
// clawMotor            motor         3              
// wallMotor            motor         8              
// ---- END VEXCODE CONFIGURED DEVICES ----


//OBJECTIVE
// - Autonomous: Sweep more discs onto own side for easier goals
// - Possibly prevent opponents' scores during period in order to prevent AWS
// - Count for 15 seconds to reach time limit at the same time(if possible)
//END OBJECTIVE


#include "vex.h"


using namespace vex;


// A global instance of competition
competition Competition;
// define your global instances of motors and other devices here
/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/
void pre_auton(void) {
// Initializing Robot Configuration. DO NOT REMOVE!
vexcodeInit();
clawMotor.setTimeout(5, seconds);
clawMotor.setStopping(hold);
clawMotor.setMaxTorque(60, percent);
wallMotor.setTimeout(6, seconds);
clawMotor.setPosition(200, degrees);
}
void rotate(){
 wallMotor.spin(reverse, 50, velocityUnits::pct);
 wait(2, seconds);
 wallMotor.stop();
}
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
void autonomous(void){
 pre_auton();
 wallMotor.spinToPosition(0, degrees);
 Drivetrain.turnFor(left, 90, degrees);
 Drivetrain.driveFor(forward, 400, mm, 50, velocityUnits::pct);
 Drivetrain.turnFor(left, 90, degrees);
 Drivetrain.driveFor(forward, 100, mm);
 rotate();
 Drivetrain.driveFor(reverse, 100, mm);
 Drivetrain.turnFor(right, 135, degrees);
 wallMotor.spinToPosition(0, degrees);
 Drivetrain.driveFor(forward, 700, mm, 50, velocityUnits::pct);
 Drivetrain.turnFor(left, 45, degrees);
 Drivetrain.driveFor(forward, 200, mm);
 rotate();
 Drivetrain.driveFor(reverse, 200, mm);
 Drivetrain.turnFor(right, 135, degrees);
 Drivetrain.driveFor(forward, 900, mm);
 Drivetrain.turnFor(left, 45, degrees);
 wallMotor.spinToPosition(200, degrees);
}
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
void usercontrol(void) {
// User control code here, inside the loop
while (1) {
  // This is the main execution loop for the user control program.
  // Each time through the loop your program should update motor + servo
  // values based on feedback from the joysticks.
  // ........................................................................
  // Insert user code here. This is where you use the joystick values to
  // update your motors, etc.
  // ........................................................................
  wait(20, msec); // Sleep the task for a short amount of time to
                  // prevent wasted resources.
}
}
//
// Main will set up the competition functions and callbacks.
//
int main() {
// Set up callbacks for autonomous and driver control periods.
Competition.autonomous(autonomous);
Competition.drivercontrol(usercontrol);
// Run the pre-autonomous function.
pre_auton();
// Prevent main from exiting with an infinite loop.
while (true) {
  wait(100, msec);
}
}
